export default {
  name: 'radio',
};
