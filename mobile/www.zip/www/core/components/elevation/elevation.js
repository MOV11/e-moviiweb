export default {
  name: 'elevation',
};
